/*
 * msgbox popup manager
 *
 * this provides a system for poping up message boxes, in order to display
 * alerts, errors, etc.
 */ 

(function(){

require([
    'jquery',
    'util/template',
    'part/session',
    'part/env',
], function(
    $,
    render
){
//////////////////////////////////////////////////////////////////////////////

function msgbox(){
    var self = this;

    this.popup = function(type, options){
        if(['error', 'alert', 'info'].indexOf(type) < 0)
            throw new Error('unknown type for poping up a new window');

        var html = render('msgbox-' + type, options);
        var newWindow = ENIGMA_CLIENT.session.newWindow();

        newWindow.allowHide(false);
        newWindow.$().html(html);

        // add content and title, basing on an option

        newWindow.show();
    };

    return this;
};



ENIGMA_CLIENT.msgbox = new msgbox();

//////////////////////////////////////////////////////////////////////////////
}); })();
