var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var commonFields = require('./User').select;

var messageSchema = Schema({
    // message type
    action: {
        type: String,
        required: true    
    },
    // created date
    created_at: {
        type: Date,
        default: Date.now
    },
    // trigger user
    sender: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    },
    // receiver
    receiver: {
        type: Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    // read status
    read_status: {
        // has read
        has_read: {
            type: Boolean,
            default: false
        },
        // read date
        read_at: Date,
        // read platform
        read_source: {
            type: String,
            enum: ['web', 'email', 'wap', 'app', 'android', 'ios'],
            default: 'web'
        }
    },
    details: {
        id: Schema.Types.ObjectId,
        content: String,
        url: String
    },
    // message content
    summary: String,
    // on which platform to trigger the message
    source: {
        type: String,
        enum: ['web', 'email', 'wap', 'app', 'android', 'ios'],
        default: 'web'
    }
});

messageSchema.statics.add = function(data, callback) {
    this.create(data, callback);
};

// list messages by uid
messageSchema.statics.listByUid = function(uid, callback) {
    this.find({
        receiver: uid,
        'read_status.has_read': false
    }).sort('-created_at').populate('sender', commonFields).exec(callback);
};

messageSchema.statics.setRead = function(id, callback) {
    this.findByIdAndUpdate(id, {
        $set: {
            'read_status.has_read': true,
            'read_status.read_at': Date.now()
        }
    }, callback);
};


module.exports = mongoose.model('Message', messageSchema);