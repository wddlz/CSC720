(function () {
	'use strict';

	angular
		.module('TasksDirective', [])
		.directive('ngFocus', focusTask)
		.directive('addTask', addTask)
		.directive('taskTitle', taskTitle);

	function focusTask ($timeout) {
		return {
			'restrict' : 'A',
			'link' : function ($scope, element, attribute) {
				$scope.$watch(attribute.ngFocus, function (newVal, oldVal) {
					if (newVal) {
						$timeout(function () {
							element[0].focus();
						}, 0, false);
					}
				});
			}
		}
	}

	function addTask () {
		return {
			'restrict' : 'C',
			'link' : function ($scope, element, attribute) {
				$scope.$watch('task.title', function (newVal, oldVal) {
					element.removeClass('has-error');

					if (($scope.newFormTask.$dirty && !$scope.newFormTask.$pristine) && !newVal) {
						element.addClass('has-error');
					}
				});
			}
		}
	}

	function taskTitle () {
		return {
			'restrict' : 'C',
			'link' : function ($scope, element, attribute) {
				$scope.$watch('task', function (newVal, oldVal) {
					element.removeClass('task-completed');
					$scope.updatedMsg = 'Modified ';

					if ($scope.task.isCompleted) {
						element.addClass('task-completed');
						$scope.updatedMsg = 'Completed ';
					}
				});
			}
		}
	}
})();
