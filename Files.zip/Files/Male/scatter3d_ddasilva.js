
var COLOR_BG = 0x2c2c2c;  /* background */
var COLOR_FL = 0x000000;  /* floor */
var COLOR_LN = 0x1a1a1a;  /* axis lines */
var COLOR_AL = 0xffffff;  /* aixs labels */
var COLOR_FG = 0xff0000;  /* dots */

var SIZE = 20;

var scene, camera, renderer, controls;

init();
animate();


function init() {
    // camera
    camera = new THREE.PerspectiveCamera(45, window.innerWidth/window.innerHeight, 0.1, 1000);    
    controls = new THREE.OrbitControls(camera);

    setInitialCameraPosition();

    // world
    scene = new THREE.Scene();

    addFloor();
    addWalls();
    addAxisLines();
    addAxisTicks();
    addAxisLabels();
    addDots();

    // renderer
    renderer = new THREE.WebGLRenderer({antialias: true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(COLOR_BG, 1);
    document.body.appendChild(renderer.domElement);
}


function animate() {
    requestAnimationFrame(animate);       
    controls.update();
    render();
}


function render() {
    renderer.render(scene, camera);
}


/**
 * Set the initial camera position.
 */ 
function setInitialCameraPosition() {
    camera.position.z = 41
    camera.position.y = 33;
    camera.position.x = 40;
}

/**
 * Adapted from: 
 * http://stemkoski.github.io/Three.js/Sprite-Text-Labels.html
 */
 function getTextSprite(text) {
     var canvas, context;
     var texture, material, sprite;

    canvas = document.createElement('canvas');
    
    context = canvas.getContext('2d');
    context.font = "Bold 120px Georgia";            
    context.fillStyle = "rgba(256, 256, 256, 1.0)";
    context.fillText(text, 0, 120);
    
    texture = new THREE.Texture(canvas);
    texture.needsUpdate = true;
    
    material = new THREE.SpriteMaterial({
        map: texture,
        useScreenCoordinates: false
    });

    sprite = new THREE.Sprite(material);

    return sprite;	
}


/**
 * Rotate an object around an axis.
 * 
 * Adapted from:
 * http://stackoverflow.com/questions/11060734/how-to-rotate-a-3d-object-on-axis-three-js
 */
function rotateAroundWorldAxis(object, axis, radians) {
    var rotWorldMatrix = new THREE.Matrix4();
    rotWorldMatrix.makeRotationAxis(axis.normalize(), radians);
    rotWorldMatrix.multiply(object.matrix);                // pre-multiply
    object.matrix = rotWorldMatrix;
    object.rotation.setFromRotationMatrix(object.matrix);
}


/**
 * Add floor to the scene.
 */ 
function addFloor() {
    var geometry, material, mesh;
    
    geometry = new THREE.PlaneGeometry(SIZE, SIZE, 1, 1);
    material = new THREE.MeshBasicMaterial({
        color: COLOR_FL,
        });
    mesh = new THREE.Mesh(geometry, material);

    mesh.position.x = SIZE/2;
    mesh.position.y = 0;
    mesh.position.z = SIZE/2;
    mesh.material.side = THREE.DoubleSide;

    rotateAroundWorldAxis(mesh,
                          new THREE.Vector3(0, 1, 1),
                          Math.PI);                                 
    
    scene.add(mesh)
}


/**
 * Add floor to the scene.
 */ 
function addWalls() {
    var geometry, material, meshLeftWall, meshRightWall;
    
    geometry = new THREE.PlaneGeometry(SIZE, SIZE, 32, 32);
    material = new THREE.MeshBasicMaterial({
            color: COLOR_FL,
        });

    // left wall
    meshLeftWall = new THREE.Mesh(geometry, material);

    meshLeftWall.position.x = 0;
    meshLeftWall.position.y = SIZE/2
    meshLeftWall.position.z = SIZE/2;
    meshLeftWall.material.side = THREE.DoubleSide;

    rotateAroundWorldAxis(meshLeftWall,
                          new THREE.Vector3(0, 1, 0),
                          Math.PI/2);

    scene.add(meshLeftWall);

    // right wall
    meshRightWall = new THREE.Mesh(geometry, material);

    meshRightWall.position.x = SIZE/2;
    meshRightWall.position.y = SIZE/2
    meshRightWall.position.z = 0;
    meshRightWall.material.side = THREE.DoubleSide;

    rotateAroundWorldAxis(meshRightWall,
                          new THREE.Vector3(0, 0, 1),
                          -Math.PI/2);

    scene.add(meshRightWall);

    // grids
    var gridMaterial = new THREE.LineBasicMaterial({
        color: COLOR_LN,
        linewidth: 5,
    });
    
    for (var i = 0; i < SIZE; i++) {
        var gridGeomtry = new THREE.Geometry();
        gridGeomtry.vertices.push(new THREE.Vector3(i,    0, 0));
        gridGeomtry.vertices.push(new THREE.Vector3(i, SIZE, 0));
        
        var line = new THREE.Line(gridGeomtry, gridMaterial);
        scene.add(line);
    }

    for (var i = 0; i < SIZE; i++) {
        var gridGeomtry = new THREE.Geometry();
        gridGeomtry.vertices.push(new THREE.Vector3(i, 0, 0));
        gridGeomtry.vertices.push(new THREE.Vector3(i, 0, SIZE));
        
        var line = new THREE.Line(gridGeomtry, gridMaterial);
        scene.add(line);
    }

    for (var i = 0; i < SIZE; i++) {
        var gridGeometry = new THREE.Geometry();
        gridGeometry.vertices.push(new THREE.Vector3(0, i, 0));
        gridGeometry.vertices.push(new THREE.Vector3(0, i, SIZE));
        
        var line = new THREE.Line(gridGeometry, gridMaterial);
        scene.add(line);
    }

    for (var i = 0; i < SIZE; i++) {
        var gridGeometry = new THREE.Geometry();
        gridGeometry.vertices.push(new THREE.Vector3(0,    i, 0));
        gridGeometry.vertices.push(new THREE.Vector3(SIZE, i, 0));
        
        var line = new THREE.Line(gridGeometry, gridMaterial);
        scene.add(line);
    }

    for (var i = 0; i < SIZE; i++) {
        var gridGeometry = new THREE.Geometry();
        gridGeometry.vertices.push(new THREE.Vector3(0,    0, i));
        gridGeometry.vertices.push(new THREE.Vector3(SIZE, 0, i));
        
        var line = new THREE.Line(gridGeometry, gridMaterial);
        scene.add(line);
    }


    for (var i = 0; i < SIZE; i++) {
        var gridGeometry = new THREE.Geometry();
        gridGeometry.vertices.push(new THREE.Vector3(0,    0, i));
        gridGeometry.vertices.push(new THREE.Vector3(0, SIZE, i));
        
        var line = new THREE.Line(gridGeometry, gridMaterial);
        scene.add(line);
    }
}


function addAxisLines() {
    var material = new THREE.MeshBasicMaterial({color: COLOR_LN});
    var geometry, mesh;
        
    // Y Axis
    geometry = new THREE.CylinderGeometry(.1, .1, SIZE, 5, 5);        
    mesh = new THREE.Mesh(geometry, material);
    mesh.position.y = SIZE/2;
    scene.add(mesh);

    // X Axis
    geometry = new THREE.CylinderGeometry(.1, .1, SIZE, 5, 5);
    mesh = new THREE.Mesh(geometry, material);
    mesh.position.x = SIZE/2;
    rotateAroundWorldAxis(mesh,
                          new THREE.Vector3(0, 0, 1),
                          Math.PI/2);
    scene.add(mesh);

    // Z Axis
    geometry = new THREE.CylinderGeometry(.1, .1, SIZE, 5, 5);
    mesh = new THREE.Mesh(geometry, material);
    mesh.position.z = SIZE/2;
    rotateAroundWorldAxis(mesh,
                          new THREE.Vector3(1, 0, 0),
                          Math.PI/2);
    scene.add(mesh);
}


/** 
 * Add axis ticks.
 */
function addAxisTicks() {
    var dx = (X_MAX - X_MIN)/SIZE;
    var dy = (Y_MAX - Y_MIN)/SIZE;
    var dz = (Z_MAX - Z_MIN)/SIZE;

    // X-Axis
    for (var i = 1; i < SIZE; i += 2) {
        var x = X_MIN + dx*i;
        var label = new String(parseInt(x));
        var sprite = getTextSprite(label);
        sprite.position.x = i;
        sprite.position.y = 0;
        sprite.position.z = SIZE + 1;        
        scene.add(sprite);
    }

    // Z-Axis
    for (var i = 1; i < SIZE; i += 2) {
        var z = Z_MIN + dz*i;
        var label = new String(Math.round(z * 100) / 100);
        var sprite = getTextSprite(label);
        sprite.position.x = SIZE + 1;
        sprite.position.y = 0;
        sprite.position.z = i;        
        scene.add(sprite);
    }

    // Y Axis
    for (var i = 1; i < SIZE; i += 2) {
        var y = Y_MIN + dy*i;
        var label = new String(Math.round(y * 100) / 100);

        var leftSprite = getTextSprite(label);
        leftSprite.position.x = SIZE + 1;
        leftSprite.position.y = i;
        leftSprite.position.z = 0;        
        scene.add(leftSprite);

        var rightSprite = getTextSprite(label);
        rightSprite.position.x = 0;
        rightSprite.position.y = i;
        rightSprite.position.z = SIZE + 1;        
        scene.add(rightSprite);
    }
}


/**
 * Add Axis Labels.
 */
function addAxisLabels() {
    // X axis
    {
        var geometry, material, mesh;

        geometry = new THREE.TextGeometry("Pixel Count", {
            size: 1,
            height: .1,
            curveSegments: 2,
            font: "helvetiker",
            });
        
        material = new THREE.MeshBasicMaterial({
            color: COLOR_AL,
            overdraw: 0.5
            });
               
        mesh = new THREE.Mesh(geometry, material);

        rotateAroundWorldAxis(mesh,
                              new THREE.Vector3(1, 0, 0),
                              - Math.PI / 2);                              
        mesh.position.set(6, 0, SIZE + 4);

        scene.add(mesh);
    }


    // Z axis
    {
        var geometry, material, mesh;

        geometry = new THREE.TextGeometry("AOD at 550 nm (Dark Target)", {
            size: 1,
            height: .1,
            curveSegments: 2,
            font: "helvetiker",
            });
        
        material = new THREE.MeshBasicMaterial({
            color: COLOR_AL,
            overdraw: 0.5
            });
               
        mesh = new THREE.Mesh(geometry, material);

        rotateAroundWorldAxis(mesh,
                              new THREE.Vector3(0, 1, 0),
                              Math.PI / 2);

        rotateAroundWorldAxis(mesh,
                              new THREE.Vector3(0, 0, 1),
                              Math.PI / 2);

        mesh.position.set(SIZE + 4, 0, SIZE - 1);

        scene.add(mesh);
    }


    // Y axis
    {
        var geometry, material, mesh;

        geometry = new THREE.TextGeometry("Aerosol Absorption OD at 550 nm", {
            size: .75,
            height: .1,
            curveSegments: 2,
            font: "helvetiker",
            });
        
        material = new THREE.MeshBasicMaterial({
            color: COLOR_AL,
            overdraw: 0.5
            });
               
        mesh = new THREE.Mesh(geometry, material);

        rotateAroundWorldAxis(mesh,
                              new THREE.Vector3(0, 0, 1),
                              Math.PI / 2);

        mesh.position.set(SIZE + 4, 3, 0);

        scene.add(mesh);
    }


}
   


/**
 * Add dots to the scene.
 */
function addDots() {
    for (var i = 0; i < SCATTER.length; i++) {
        var geometry, material, mesh;
        var gammaX = (SCATTER[i][0] - X_MIN) / (X_MAX - X_MIN);
        var gammaY = (SCATTER[i][1] - Y_MIN) / (Y_MAX - Y_MIN);
        var gammaZ = (SCATTER[i][2] - Z_MIN) / (Z_MAX - Z_MIN);

        geometry = new THREE.SphereGeometry(.1, 1, 1);
        material = new THREE.MeshBasicMaterial({
            color: COLOR_FG,
            });
        mesh = new THREE.Mesh(geometry, material);

        mesh.position.x = SIZE * gammaX;
        mesh.position.y = SIZE * gammaY;
        mesh.position.z = SIZE * gammaZ;

        scene.add(mesh);
    }
}
