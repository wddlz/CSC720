(function(){ define(['crypto'], function(crypto){
//////////////////////////////////////////////////////////////////////////////

function diffcode(code){
    function getChecksumStr(input){
        var checksum = new crypto.hash('BLAKE2s', {length: 5}).hash(input);
        return crypto.util.encoding(checksum.buffer).toBase32();
    };
    if(undefined === code){
        var src = new crypto.util.srand().bytes(15),
            str = crypto.util.encoding(src).toBase32();
        var checksum = getChecksumStr(src);
        var ret =
            str.slice(0, 8) + '-' +
            checksum.slice(0, 4) + '-' +
            str.slice(8, 12) + '-' +
            checksum.slice(4, 8) + '-' +
            str.slice(12, 24)
        ;
        return ret;
    } else {
        var t = /^[0-9a-z]{8}\-([0-9a-z]{4}\-){3}[0-9a-z]{12}$/i;
        if(!t.test(code)) return false;
        code = code.toLowerCase();
        var str = code.slice(0, 8) + code.slice(14, 18) + code.slice(24, 36);
        var checksum = code.slice(9, 13) + code.slice(19, 23);
        var src = crypto.util.encoding(str, 'base32').toArrayBuffer();
        rechecksum = getChecksumStr(src);
        return checksum === rechecksum;
    };
};

return diffcode;
//////////////////////////////////////////////////////////////////////////////
}); })();
