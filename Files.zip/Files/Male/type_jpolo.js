var $type = (function () {
  var
  type             = {},
  DESCRIPTORS      = "__descriptors__",
  PROTOS           = "__protos__",
  MRO              = "__mro__",
  isCallable       = $object.isCallable,
  isFunction       = $object.isFunction,
  __all__          = (function () {
    return Object
      .getOwnPropertyNames(global)
      .filter(function (n) {
        return $string.isUpperCase(n.charAt(0)) && isFunction(global[n]) && global[n].prototype;
      })
      .map(function (n) { return global[n]; })
      .map($function.getPrototype);
  }()),
  __queue__        = [],
  ObjectPrototype  = Object.prototype,
  ObjectPrototypes = Object.freeze([]),
  arrayAdd         = $array.add,
  arrayContains    = $array.contains,
  arrayFilter      = $array.filter,
  arrayIndexOf     = $array.indexOf,
  arrayIsEmpty     = $array.isEmpty,
  arraySome        = $array.some,
  arrayEvery       = $array.every,
  arrayMap         = $array.map,
  functionAssert   = $function.assert,
  objectAssert     = $object.assert,
  objectPrototypeOf = $object.getPrototypeOf,
  objectDescriptors = $object.getOwnPropertyDescriptors,
  ToObject         = Object;



  //add internals
  $object.INTERNAL[DESCRIPTORS] = 
  $object.INTERNAL[PROTOS] = 
  $object.INTERNAL[MRO] = 
  true;

  $function.addMethods(std.Prototypes, {
    onChange: function () {
      onChange(this.__owner__, true);
    }
  });


  type.create = function (name, parents, properties) {
    $path.assert(name, String);
    type.assert(parents, Array);
    var klass = create(name, parents, properties);
    $module.set(name, klass);
    return klass;
  };

  /**
   * Return `fn` name
   * 
   * @param {Function} fn
   * @return {String}
   */
  type.getName = function getName(o) {
    return $function.getName(isFunction(o) ? o : o.constructor);
  };

  /**
   * Define properties
   *
   * @param {Object} o
   * @param {Object} descriptors
   */
  type.defineProperties = function defineProperties(o, descriptors) {
    objectAssert(o, "type.defineProperties");
    descriptors = ToObject(descriptors);

    var name, odescriptors;
    //patch descriptor for prototype
    if ($object.isPrototype(o)) {
      for (name in descriptors) {
        descriptors[name].enumerable = false;
      }
    }

    if (isType(o)) {
      odescriptors = type.getDescriptors(o);
      Object.defineProperties(o, descriptors);
      $object.merge(descriptors, odescriptors);
      onChange(o, true);
    } else {
      //classic prototypal inheritance
      Object.defineProperties(o, descriptors);
    }
  };

  /**
   * Define property
   *
   * @param {Object} o
   * @param {String} name
   * @param {Object} descriptor
   */
  type.defineProperty = function defineProperty(o, name, descriptor) {
    var desc = {};
    desc[name] = descriptor;
    type.defineProperties(o, desc);
  };

  type.getDescriptors = function getDescriptors(o) {
    objectAssert(o, "type.getDescriptors");

    var val;
    if (isType(o)) {
      val = $object.getOwn(o, DESCRIPTORS);
      if (val === undefined) {
        //import non internal descriptors
        defineProtected(o, DESCRIPTORS, val = objectDescriptors(o));
      }
    } else {
      //classic prototypal inheritance
      val = objectDescriptors(o);
    }
    return val;
  };

   /**
   * Return constructor
   * 
   * @param {String} baseName
   * @return {Function}
   */
  type.constructor = $function.constructor;

  /**
   * 
   *
   * @param {Object} object
   */
  type.prototypeOf = objectPrototypeOf;

  /**
   * 
   *
   * @param {Object} o
   * @return {Array}
   */
  type.prototypesOf = function prototypesOf(o) {
    objectAssert(o, 'type.prototypesOf');

    if (o === ObjectPrototype) {//never change Object.prototype
      return ObjectPrototypes;
    }
    var val = $object.getOwn(o, PROTOS);
    if (val === undefined) {
      type.getDescriptors(o);//lazy init
      arrayAdd(__all__, o);//register
      defineProtected(o, PROTOS, val = new std.Prototypes(o));
    }
    return val;
  };

  /**
   * Return true if `object` is instance of `klass`
   * 
   * @param {Object} object
   * @param {Function} typeBase
   * @return {Boolean}
   */
  type.instanceOf = function instanceOf(o, typeBase) {
    if (o === undefined || o === null) {
      return false;
    }

    var str = $object.str(o);
    switch (typeBase) {
      case Object: return true;
      case Boolean: return str === '[object Boolean]';
      case String: return str === '[object String]';
      case Number: return str === '[object Number]';
      case Array: return str === '[object Array]';
      case Function: return typeof o === "function";
      default:
        if (typeBase.__instanceOf__) {
          return typeBase.__instanceOf__(o);
        } else if (o instanceof typeBase) {
          return true;
        } else {
          var mro = $object.getOwn(objectPrototypeOf(o), MRO);
          return mro ? arrayContains(mro, typeBase.prototype) : false;
        }
    }
  };

  /**
   * 
   * 
   * @param {Function} typeChild
   * @param {Function} typeBase
   * @return {Boolean}
   */
  type.isChildOf = function isChildOf(typeChild, typeBase) {
    functionAssert(typeChild, "type.isChildOf");
    functionAssert(typeBase, "type.isChildOf");
    var protoChild = typeChild.prototype, protoBase = typeBase.prototype;

    return (
      protoChild === protoBase || typeBase === Object ? true : 
      isType(typeBase) ? typeChild instanceof typeBase :
      arrayContains(type.mro(typeBase), typeChild)
    ); 
  };

  /**
   * Return an array of prototypes 
   *
   * @param {Object} object
   * @return {Array}
   */
  type.mro = function mro(o) {
    objectAssert(o, "type.mro");

    var val;
    if (isType(o)) {
      val = $object.getOwn(o, MRO);
      if (val === undefined) {
        val = [o].concat(c3MROMerge(arrayMap(type.prototypesOf(o), mro)));
        defineProtected(o, MRO, val);
      }
    } else {
      //classic prototypal inheritance
      val = [o].concat($object.getPrototypesOf(o));
    }
    return val;
  };

  type.assert = function assert(o, klass) {
    if (!type.instanceOf(o, klass)) {
      throw new TypeError(o + " is not a valid " + type.getName(klass));
    }
    return o;
  };

  /**
   * Apply super method
   * 
   * @param {Function} callee
   * @param {String} methodName
   * @param {Object} self
   * @param {Array|Arguments} args
   * @return {*}
   */
  type.$super = function $super(callee, methodName, self, args) {
    type.assert(callee, Function);
    type.assert(methodName, String);
    objectAssert(self);
    
    var 
    calleeProto = callee.prototype,
    proto    = objectPrototypeOf(self),
    protoMRO, method, parent, i, l;

    if (isType(self)) {
      protoMRO = type.mro(proto);
      i = arrayIndexOf(protoMRO, calleeProto);
      l = protoMRO.length;
      if (i >= 0) {
        i += 1;
        while (i < l) {
          method = $object.getOwn(protoMRO[i], methodName);
          //method = protoMRO[i][methodName];
          if (typeof method !== "undefined") {
            break;
          }
          i += 1;
        }
      } else {
        throw new Error(type.getName(calleeProto) + " not found in mro of " + type.getName(proto));
      }
    } else {

      //prototypal way
      parent = (objectPrototypeOf(calleeProto) || ObjectPrototype);
      method = parent[methodName];
    }
    
    if (method) {
      switch (args.length) {
        case 0: return method.call(self);
        case 1: return method.call(self, args[0]);
        case 2: return method.call(self, args[0], args[1]);
        case 3: return method.call(self, args[0], args[1], args[2]);
        case 4: return method.call(self, args[0], args[1], args[2], args[3]);
        default: return method.apply(self, args);
      }
    }
  };

  type.applySuper = type.$super;


  function create(name, parents, properties) {
    parents = (parents || $array.empty).slice(0);

    var base = $function.constructor(name);

    //inherits
    if (parents.length === 0) {
      arrayAdd(parents, Object);
    }
    $function.inherits(base, parents[0]);
    type.prototypesOf(base);
    type.prototypesOf(base.prototype).update(arrayMap(parents, $function.getPrototype));

    //properties
    if (properties) {
      if (isCallable(properties)) {
        properties = properties.call(base, base);
      }

      if (properties) {
        type.defineProperties(base.prototype, objectDescriptors(properties));
      }
    }
    return base;
  }

  function getChildren(o) {
    if (o === ObjectPrototype) {
      return __all__;
    }
    return arrayFilter(__all__, function (t) {
      return type.isChildOf(t.constructor, o.constructor);
    });
  }

  function c3MROMerge(arrayOfarray) {
    var 
    mro = [],
    current = $array.clone(arrayOfarray),
    type, found, i, l;

    function arrayRestContainsType(a) {
      return arrayIndexOf(a, type, 1) >= 0; 
    }

    function arrayPopType(a) {
      return a[0] === type ? a.slice(1) : a;
    }

    while (true) {
      found = false;
      l = current.length;
      for (i = 0; i < l; ++i) {
        if (current[i].length !== 0) {
          type = current[i][0];

          if (!arraySome(current, arrayRestContainsType)) {//in tail
            found = true;
            arrayAdd(mro, type);
            current = arrayMap(current, arrayPopType);
            break;
          }
        }
      }
      if (!found) {
        if (arrayEvery(current, arrayIsEmpty)) {
          return mro;
        }
        throw new Error("Cannot create a consistent method resolution order (MRO)");
      }
    }
  }

  function onChange(o, opt_resolve) {
    var trait, mro, descriptors, descriptorNew, descriptorOld, children, l, propertyName;
    if (arrayAdd(__queue__, o)) {
      //unset cache
      delete o[MRO];
      children = getChildren(o);
      l = children.length;
      while (l--) {
        onChange(children[l], false);
      }
    }

    if (opt_resolve) {
      __queue__ = c3MROMerge(arrayMap(__queue__, type.mro));
      while (__queue__.length) {
        trait = __queue__.pop();
        if (isType(trait)) {
          mro = type.mro(trait);
          descriptors = {};

          l = mro.length;
          while (l--) {
            $object.merge(type.getDescriptors(mro[l]), descriptors);
          }

          for (propertyName in descriptors) {
            descriptorNew = descriptors[propertyName];
            descriptorOld = $object.getPropertyDescriptor(trait, propertyName);

            if (descriptorOld && $object.equals(descriptorNew, descriptorOld)) {
              delete descriptors[propertyName];
            }
          }

          //finally export
          Object.defineProperties(trait, descriptors);
        }
      }
    }
  }

  function isType(o) {
    return PROTOS in o;
  }

  //util
  function defineProtected(o, name, value) {
    Object.defineProperty(o, name, {
      value: value,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }

  //export
  return type;
}());