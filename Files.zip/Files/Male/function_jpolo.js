var $function = (function () {

  var 
  functionString    = Function.prototype.toString,
  objectCreate      = Object.create,
  objectDescriptor  = $object.getOwnPropertyDescriptor,
  objectDescriptors = $object.getOwnPropertyDescriptors,
  objectDefine      = Object.defineProperty,
  objectMerge       = $object.merge,
  stringify         = String;

  function assert(o, opt_method) {
    if (typeof o !== "function") {
      throw new TypeError(
        opt_method ? opt_method + " called on a non-function" :
        o + " is not a function"
      );
    }
  }

  function construct(Class, thisp, args) {
    var 
    apply  = Class.__apply__,
    isCall = !(thisp instanceof Class), init;
    
    if (isCall) {
      if (apply) {
        return apply.apply(Class, args);
      }
      thisp = objectCreate(Class.prototype);
    }
    
    init = thisp.__new__;
    if (init) {
      switch (args.length) {
        case 0: init.call(thisp);break;
        case 1: init.call(thisp, args[0]);break;
        case 2: init.call(thisp, args[0], args[1]);break;
        case 3: init.call(thisp, args[0], args[1], args[2]);break;
        case 4: init.call(thisp, args[0], args[1], args[2], args[3]);break;
        default: init.apply(thisp, args);
      }
    }
    if (isCall) {
      return thisp;
    }
  }

  function constructor(fullName) {
    var
    baseName = $path.baseName(fullName),
    /*jslint evil: true*/
    builder  = new Function("construct",
      "return (function " + baseName + "() {\n" +
      "  return construct(" + baseName + ", this, arguments);\n" +
      "});"
    ),
    /*jslint evil: false*/
    ctor     = builder(construct);
    
    setName(ctor, fullName);
    ctor.toString = function toString() {
      return "[type " + getName(this) + "]";
    };
    return ctor;
  }

  function getName(fn) {
    assert(fn);
    var name = fn.displayName || fn.name, fnName;
    if (name) {
      return name;
    } else {
      fnName = functionString.call(fn);
      fnName = fnName.substr('function '.length);
      fnName = fnName.substr(0, fnName.indexOf('('));
      fn.displayName = fnName;//cache it
      return fnName;
    }
  }

  function setName(fn, val) {
    assert(fn);
    val = stringify(val);

    var str = functionString.call(fn);
    str = 'function ' + val + str.slice(str.indexOf('('));

    fn.displayName = val;
    fn.toString = function toString() {
      return str;
    };
  }

  function getPrototype(fn) {
    assert(fn);
    return fn.prototype; 
  }

  function inherits(base, parent) {
    assert(base);
    assert(parent);
    var proto = base.prototype;
    base.prototype = Object.create(
      parent.prototype, 
      objectDescriptors(proto, true)
    );
  }

  function addMethods(fn, properties) {
    assert(fn);
    var 
    proto = fn.prototype, propertyName, descriptor;
    objectMerge(properties, proto);

    //fix prototype
    for (propertyName in proto) {
      //TODO change to $object.DESCRIPTOR_HIDDEN
      descriptor = objectDescriptor(proto, propertyName);
      descriptor.enumerable = false;
      objectDefine(proto, propertyName, descriptor);
    }
  }

  function str(fn) {
    return functionString.call(fn);
  }


  //add internal
  $object.INTERNAL.displayName = true;

  

  return {
    assert: assert,
    addMethods: addMethods,
    constructor: constructor,
    getPrototype: getPrototype,
    getName: getName,
    inherits: inherits,
    setName: setName,
    str: str
  };
}());