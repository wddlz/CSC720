
/**
 * Return a new class function
 * 
 * @param {String} name
 * @param {Array} parents
 * @param {Object} properties
 * @return {Function}
 */
function type(name, parents, properties) {
  return $type.create(name, parents, properties);
}

//expose functions
$object.merge($type, type);


/**
 * Return a new module object
 * 
 * @param {String} name
 * @param {Object|Function} properties
 * @return {Module}
 */
type.module = function module(name, properties) {
  return $module.create(name, properties);
};

type.path = $path;

/**
 *
 * @param {string} string
 * @return {*}
 */
type.require = function require(string) {
  var m = $module.get(string);
  if (m === undefined) {
    throw new Error(string + " does not exist");
  }
  return m;
};


//GLOBAL
global.std = std;
global.type = type;

//COMMONJS
if (typeof module !== "undefined") {
  module.exports = type;
}

//AMD
if (global.define) {
  global.define("type", [], function () { return type; });
}
