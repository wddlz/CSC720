var $string = (function () {
  var 
  stringify    = String,
  fromCharCode = String.fromCharCode,
  floor        = Math.floor,
  frandom      = Math.random,
  objectString = $object.isString;

  function assert(o) {
    if (!objectString(o)) {
      throw new TypeError(o + " is not a string");
    }
  }

  function isEmpty(s) {
    return stringify(s).length === 0;
  }

  function isUpperCase(s) {
    return stringify(s).toUpperCase() === s;
  }

  function random(minLength, maxLength) {
    var 
    length = (minLength||0) + floor(frandom() * (maxLength||32)), 
    str = "";
    while (length--) {
      str += fromCharCode(32 + floor(95 * frandom()));
    }
    return str;
  }

  return {
    assert: assert,
    isEmpty: isEmpty,
    isUpperCase: isUpperCase,
    random: random,
    str: stringify
  };
}());