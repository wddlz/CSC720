// load site config
var siteConfig = require("./config/site.json"),
    dbConfig = require("./config/database.json"),
    socket = require("socket.io"),
    passport = require("passport"),
    LocalStrategy = require("passport-local").Strategy,
    Hook = require('./lib/hook'),
    api = require("./routes/api"),
    log = require('spm-log'),
    mongoose = require('mongoose'),
    Message = mongoose.model('Message'),
    User = user = mongoose.model('User'),
    Config = require('./config/app'),
    ENV = Config.ENV,
    commonUserFields = require('./models/User').select,
    onHeaders = require('on-headers');


// middlewares
var shouldBeAdmin = require('./middlewares/limiter/admin').shouldBeAdmin;


var express = require("express.oi"),
    routes = require("./routes");
// extend express
require('./lib/extendExpress')(express);

var app = express(),
    flash = require("connect-flash");
app.http().io();

global.io = app.io;

//app.io.set('transports', ['websocket']);

// body parser
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));

// response time
app.use(require('response-time')());


// custom header
app.use(function(req, res, next) {
    app.disable("x-powered-by");
    res.setHeader("X-Powered-By", "Raose:Team Collaboration Tool");
    next();
});

passport.use(new LocalStrategy(function(username, password, done) {
    User.check(username, password, done)
}));

passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(user, done) {
    User.findOne({
        username: user.username
    }, commonUserFields, function(err, user) {
        if (user && user.username) {
            done(err, {
                username: user.username,
                uid: user._id.toString()
            });
        } else {
            done('no user', {
                username: null,
                uid: 0
            });
        }

    });
});

var session = require('express-session');
var MongoStore = require("connect-mongo")(session);

// Configuration
if (ENV === 'product') {
    // server too busy detector
    app.use(require('./middlewares/toobusy'));
    app.set('json spaces', 0);
    app.set('view cache', 'true');
} else {
    app.disable('view cache');
}

app.options('*', require('cors')());

// xss filter
var xssFilter = require('x-xss-protection');
app.use(xssFilter());

// log request time
app.use(function(req, res, next) {
    var start = Date.now();
    onHeaders(res, function() {
        var duration = Date.now() - start;
        Hook.emit('request:sent', req.method, req.originalUrl, duration);
    })
    next();
});

app.use(require('cookie-parser')(siteConfig.cookieSecret));
app.use(require('./middlewares/uuid'));

app.use(function(req, res, next) {
    res.setHeader('X-Request-Id', req.user ? req.user.uid : req.cookies.timo_uuid ? req.cookies.timo_uuid : 'anonymous');
    next();
});

app.set("views", __dirname + "/views");
app.set("view engine", "jade");
app.set("view options", {
    layout: false,
    pretty: true
});

// error handler
app.use(require('errorhandler')({
    showStack: true,
    dumpExceptions: true
}));

app.use(require('cors')());



// timeout
app.use(require('connect-timeout')(10000));

app.use(require('method-override')());
app.use(require('serve-static')(__dirname + "/public"));

var sessionConfig = {
    secret: "secret",
    maxAge: new Date(Date.now() + 36e5),
    store: new MongoStore({
        mongooseConnection: mongoose.connection
    })
};
app.use(require('express-session')(sessionConfig));
app.io.session(sessionConfig);

app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

require("./routes").setup(app, passport);

// bootstrap
var bootstrap = false;
require('./lib/bootstrap').init(function(err) {
    if (!err) {
        log.info('bootstrap', 'bootstrap done')
        bootstrap = true;
    } else {
        log.error('bootstrap error:', err);
    }
});

// all services and plugins
['/plugins', '/services'].forEach(function(one) {
    require('require-all')({
        dirname: __dirname + one,
        filter: /index.js$/,
        resolve: function(exports) {
            exports({
                Hook: Hook,
                App: app,
                IO: app.io
            });
        }
    });
});

function start(port, env, done) {
    port = port || 8004;
    var server = app.listen(port, function() {
        console.log("Express server listening on port %d in %s mode", port, app.settings.env);
        done && done();
    });
    return {
        server: server,
        io: null
    };
}

exports.bootstrap = function() {
    return bootstrap;
};
exports.start = start;
exports.app = app;