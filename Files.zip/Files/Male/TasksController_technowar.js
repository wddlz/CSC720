(function () {
	'use strict';

	angular
		.module('TasksController', [])
		.controller('TasksController', TasksController);

	function TasksController ($scope, taskFactory, tasksFactory) {
		$scope.tasks = [];
		$scope.editedTask = null;
		$scope.taskTitle = null;

		$scope.createTask = function () {
			taskFactory.create($scope.task)
				.$promise
					.then(successCreate, errorCreate);

			function successCreate (data) {
				$scope.task = '';
				$scope.tasks.push(data);
				$scope.newFormTask.$setPristine();
			}

			function errorCreate (error) {
				$scope.task = '';
				$scope.errorMsg = 'Failed to add task. Please try again later.';
			}
		};

		$scope.updateTask = function (task) {
			taskFactory.update({
				'id' : task._id
			}, {
				'title' : task.title,
				'isCompleted' : task.isCompleted
			}).$promise
					.then(successUpdate, errorUpdate);

			function successUpdate (data) {
				if (!data.isCompleted) {
					task.isEditable = false;

					$scope.editedTask = null;
					$scope.taskTitle = null;
				}

				$scope.tasks.splice($scope.tasks.indexOf(task), 1)
				$scope.tasks.push(data);
			}

			function errorUpdate (error) {
				$scope.errorMsg = 'Failed to update task. Please try again later.';
			}
		};

		$scope.deleteTask = function (task) {
			taskFactory.delete({
				'id' : task._id
			}).$promise
					.then(successDelete, errorDelete);

			function successDelete (data) {
				$scope.tasks.splice($scope.tasks.indexOf(task), 1)
			}

			function errorDelete (error) {
				$scope.errorMsg = 'Failed to delete task. Please try again later.';
			}
		};

		$scope.getTasks = function () {
			tasksFactory.query()
				.$promise
					.then(successQuery, errorQuery);

			function successQuery (data) {
				$scope.tasks = data;
				$scope.errorMsg = 'There are no more pending tasks.';
			}

			function errorQuery (error) {
				$scope.errorMsg = 'Failed to connect to server. Please try again later.';
			}
		};

		$scope.isUpdatingTask = function (task) {
			if (!task.isCompleted) {
				task.isEditable = true;

				$scope.editedTask = task;
				$scope.taskTitle = task.title;
			}
		};

		$scope.cancelUpdate = function (task) {
			task.isEditable = false;
			task.title = $scope.taskTitle;

			$scope.editedTask = null;
			$scope.taskTitle = null;
		};
	}
})();
