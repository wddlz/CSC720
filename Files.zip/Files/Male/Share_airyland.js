var mongoose = require('../lib/mongoose'),
	Schema = mongoose.Schema;
var ObjectId = Schema.Types.ObjectId;
var Hook = require('../lib/hook');

var shareSchema = Schema({
	workspace: {
		type: ObjectId,
		ref: 'Workspace'
	},
	created_by: {
		type: 　ObjectId,
		ref: 'User',
	},
	created_at: {
		type: Date,
		default: Date.now
	},
	title: {
		type: String,
		required: true
	},
	content: {
		type: String,
		required: true
	},
	labels: [],
	is_deleted: {
		type: Boolean,
		default: false
	},
	deleted_at: {
		type: Date
	},
	deleted_by: {
		type: ObjectId,
		ref: 'User'
	}
});

shareSchema.statics.list = function(wid, limit, page, cb) {
	this.find({
		workspace: wid
	}, '-is_deleted -deleted_at -deleted_by').skip(limit * (page - 1)).limit(limit).exec(cb);
};

shareSchema.statics.add = function(data, cb) {
	this.create(data, function(err, _data) {
		if (!err) {
			Hook.emit('share:created', _data);
		}
		cb(err, _data);
	});
};

shareSchema.statics.delete = function(sid, cb) {
	this.findById(sid, function(err, data) {
		if (err) {
			return cb('not existed');
		} else {
			data.remove(function(err) {
				if (!err) {
					Hook.emit('share:deleted', data);
				}
				cb(err);
			});
		}
	});
};

module.exports = mongoose.model('share', shareSchema);