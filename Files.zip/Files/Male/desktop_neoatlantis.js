(function(){
require([
    'jquery',
    'util/template',
], function(
    $,
    render
){
//////////////////////////////////////////////////////////////////////////////
var a = render('desktop-identity-entry', {subject: 'test'});

function desktop(){
    var self = this;

    var __desktop = $('#session-workspace-desktop');
        $desktop = function(x){return __desktop.find(x);};

    var desktopHTML = render('desktop-basic', {});
    __desktop.empty().html(desktopHTML);

    var contactList = [];
    function redrawContactList(){
        var html = render('desktop-contact-list', {list: contactList});
        $desktop('[name="contact-list"]').empty().html(html);
    };

    redrawContactList();


    /* bind events */

    this.setContactList = function(list){
        contactList = list;
        redrawContactList();
    };

    return this;
};

ENIGMA_CLIENT.desktop = new desktop();

//////////////////////////////////////////////////////////////////////////////
}); })();
