/*!
 * twttr v0.0.2 (http://git.io/twttrjs)
 * Licensed under the MIT License.
 */

module.exports = function (text, options, trim) {
  'use strict';

  //
  // Define options
  //

  var vowels = ['a', 'e', 'i', 'o', 'u'];

  // Known options
  var known = {
    // Remove vowels
    noVowels: function () {
      for (var i = 0; i < vowels.length; i++) {
        text = text.replace(new RegExp(vowels[i], 'gi'), '');
      }
    },

    // Remove Y
    noY: function () {
      text = text.replace(/y/gi, '');
    },

    // Replace you with u
    yoU: function () {
      vowels.splice(vowels.indexOf('u'), 1);
      text = text.replace(/\byou(r(self)?)?\b/gi, 'u$1');
    },

    // Replace O with zero
    zerO: function () {
      text = text.replace(/o/gi, '0');
    }
  };

  //
  // Load options
  //

  // Set default
  if (!options || !options.length) {
    options = 'noVowels';
  }

  // Convert string into array
  if (typeof options === 'string') {
    options = options.split(' ');
  }

  // Imitate default option(s) with 'default'
  // Hack this to set custom default option(s)
  if (options.indexOf('default') > -1) {
    options.push('noVowels');
    options.splice(options.indexOf('default'), 1);
  }

  // Loading loop
  for (var i = 0; i < options.length; i++) {
    if (known.hasOwnProperty(options[i])) {
      known[options[i]]();
    }
  }

  //
  // Whitespace
  //

  // Trim leading, trailing and multiple whitespace
  if (trim === undefined) {
    trim = true;
  }

  if (trim) {
    text = text
      .replace(/\s{2,}/g, ' ')
      .replace(/(^\s+|\s+$)/g, '');
  }

  return text;
};
